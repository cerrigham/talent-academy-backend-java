import java.util.Arrays;
import java.util.List;

import com.fasterxml.classmate.AnnotationConfiguration;
import entity.Book;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.jpa.QueryHints;
import org.hibernate.cfg.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;

public class TutorialCriteria {

    public static void main(String[] args) {
        SessionFactory sessionFactory = new Configuration().configure()
                .buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();



        CriteriaBuilder cb = session.getCriteriaBuilder();
        CriteriaQuery<Book> cq = cb.createQuery(Book.class);
        cq.from(Book.class);

        List<Book> books = session.createQuery(cq).getResultList();
        books.stream().forEach(s -> System.out.println(s));

        session.getTransaction().commit();
        session.close();

    }
}
