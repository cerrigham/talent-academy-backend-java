import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import entity.Book;
import entity.Borrow;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;

public class TutorialJpa {

    public static void main(String[] args) {
            SessionFactory sessionFactory = new Configuration().configure()
                    .buildSessionFactory();
            Session session = sessionFactory.openSession();
            session.beginTransaction();

            final String selectAllBooksQuery = "SELECT b FROM Book b";
            final String selectAllBorrows = "SELECT b FROM Borrow b";

            Query query = session.createQuery(selectAllBooksQuery);
            List books = query.getResultList();
            System.out.println(Arrays.toString(books.toArray()));

            Query<Borrow> queryBorrow = session.createQuery(selectAllBorrows);
            List<Borrow> borrows = queryBorrow.list();
            borrows.stream().forEach(s -> System.out.println(s));

            session.getTransaction().commit();
            session.close();
        }
}
