import java.io.File;
import java.util.Arrays;
import java.util.List;

import entity.Book;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class TutorialJpa {

    public static void main(String[] args) {
            SessionFactory sessionFactory = new Configuration().configure()
                    .buildSessionFactory();
            Session session = sessionFactory.openSession();
            session.beginTransaction();

            String selectAllBooksQuery = "SELECT b FROM Book b";
            Query query = session.createQuery(selectAllBooksQuery);
            List<Book> books = query.list();
            System.out.println(Arrays.toString(books.toArray()));

            session.getTransaction().commit();
            session.close();
        }
}
