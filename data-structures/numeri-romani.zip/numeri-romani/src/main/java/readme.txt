creare un convertitore di numeri romani

I = 1
V = 5
X = 10
L = 50
C = 100
D = 500
M = 1000

il programma deve avere un metodo che preso in input una stringa "romana" (esempio XVI) la trasformi in decimale
(esempio 16).
Se passo la stringa "XIV" mi deve ritornare 14.
Voglio anche validare la correttezza della stringa, quindi stringhe come XIVV, IIIII non sono valide.
Predisporre anche i test per ogni metodo.

TODO
classe con numeri romani --> con la mappa *
classe per controllare correttezza stringa
classe convertitore
la stringa possiamo controllarla nel convertitore volendo
una volta convertita ha finito
scrivere una classe di test (implicito non è)


Matteo farebbe funzioni differenti nella stessa classe
business logic - modello (dato)

3 classi + 1 classe di teste
packages? si no forse

MMMXCVI = 3096   lenght 7
0123456          1 < 7
                 3 < 7
                  ...
                  6
                  7 < 7

0-1
2-3
4-5