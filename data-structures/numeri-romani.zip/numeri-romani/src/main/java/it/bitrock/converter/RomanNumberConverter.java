package it.bitrock.converter;

import it.bitrock.model.RomanNumber;
import it.bitrock.validator.RomanNumberValidator;

import java.util.Map;

public class RomanNumberConverter {

    // implementare il medoto (BONUS: se si riesce ricorsivamente)
    // itearare su una stringa, parsing
    // get element from a Map
    public static Integer romanNumberConverter(String aRomanNumber) {
        //TODO
        return 0;
    }
}
