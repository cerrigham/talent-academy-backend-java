package it.bitrock.springdatajpademo;

import it.bitrock.springdatajpademo.entity.Book;
import it.bitrock.springdatajpademo.repository.BookRepository;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class SpringDataJpaDemoApplicationTests {

	@Autowired
	BookRepository bookRepository;

	@Test
	void contextLoads() {
	}

	@Test
	void testFindByTitle(){
		String title="Due di due";
		List<Book> books = bookRepository.findByTitle(title);
		Assertions.assertThat(books.size() != 0);
	}

	@Test
	void testNotFindByTitle(){
		String title="Due di quattro";
		List<Book> books = bookRepository.findByTitle(title);
		Assertions.assertThat(books.size() == 0);
	}

}
