package it.bitrock.springdatajpademo.entity;

import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
@Data // Lombok: adds getters and setters
public class Customer {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Integer id;

    private String name;

    private String address;

    private String email;

    private String telephone;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name="customer_id")
    private List<Borrow> borrows;
}

