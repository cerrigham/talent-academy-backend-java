package it.bitrock.springdatajpademo.entity;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data // Lombok: adds getters and setters
public class Borrow {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Integer id;

    @ManyToOne
    private Book book;

    @ManyToOne
    private Customer customer;
}

