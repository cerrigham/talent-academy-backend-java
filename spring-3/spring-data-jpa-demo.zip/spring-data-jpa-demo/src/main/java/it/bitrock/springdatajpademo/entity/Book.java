package it.bitrock.springdatajpademo.entity;

import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
@Data // Lombok: adds getters and setters
public class Book {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Integer id;

    private String title;

    private String author;

    private String condition;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name="book_id")
    private List<Borrow> borrows;
}
