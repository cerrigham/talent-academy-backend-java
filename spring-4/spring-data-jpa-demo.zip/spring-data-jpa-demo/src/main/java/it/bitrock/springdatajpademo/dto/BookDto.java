package it.bitrock.springdatajpademo.dto;

import it.bitrock.springdatajpademo.entity.Borrow;
import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Data
public class BookDto {
    private String title;
    private String author;
    private String condition;
    private List<Borrow> borrows;
}
