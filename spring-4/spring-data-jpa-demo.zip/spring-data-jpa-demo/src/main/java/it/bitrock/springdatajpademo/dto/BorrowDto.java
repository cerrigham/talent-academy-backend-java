package it.bitrock.springdatajpademo.dto;

import it.bitrock.springdatajpademo.entity.Book;
import it.bitrock.springdatajpademo.entity.Customer;
import lombok.Data;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Data
public class BorrowDto {
    private Integer id;
    private Book book;
    private Customer customer;
}
