package it.bitrock.springdatajpademo.dto;

import it.bitrock.springdatajpademo.entity.Borrow;
import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Data
public class CustomerDto {
    private String name;
    private String address;
    private String email;
    private String telephone;
    private List<Borrow> borrows;
}
