package it.bitrock.springdatajpademo.component;

import it.bitrock.springdatajpademo.dto.BookDto;
import it.bitrock.springdatajpademo.dto.CustomerDto;
import it.bitrock.springdatajpademo.entity.Book;
import it.bitrock.springdatajpademo.entity.Customer;
import org.springframework.stereotype.Component;

@Component
public class DtoMapper {

    public BookDto fromBooktoBookDto(Book book) {
        BookDto bookDto = new BookDto();
        bookDto.setAuthor(book.getAuthor());
        bookDto.setBorrows(book.getBorrows());
        bookDto.setCondition(book.getCondition());
        bookDto.setTitle(book.getTitle());

        return bookDto;
    }

    public CustomerDto fromCustomerToCustomerDto(Customer customer) {
        CustomerDto customerDto = new CustomerDto();
        customerDto.setAddress(customer.getAddress());
        customerDto.setBorrows(customer.getBorrows());
        customerDto.setEmail(customer.getEmail());
        customerDto.setName(customer.getName());
        customerDto.setTelephone(customer.getTelephone());

        return customerDto;
    }
}
