package it.bitrock.springdatajpademo.Service;

import it.bitrock.springdatajpademo.component.DtoMapper;
import it.bitrock.springdatajpademo.dto.BookDto;
import it.bitrock.springdatajpademo.entity.Book;
import it.bitrock.springdatajpademo.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class BookService {

    @Autowired
    BookRepository bookRepository;

    @Autowired
    DtoMapper dtoMapper;

    public ResponseEntity<List<BookDto>> getAllBooks() {
        try {
            List<BookDto> books = new ArrayList<BookDto>();

            books = bookRepository.findAll().stream().map(b -> dtoMapper.fromBooktoBookDto(b)).collect(Collectors.toList());

            if (books.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(books, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<List<BookDto>> getBooksByTitle(String title) {
        try {
            List<BookDto> books = new ArrayList<BookDto>();
            if (title == null)
                books = bookRepository.findAll().stream().map(b -> dtoMapper.fromBooktoBookDto(b)).collect(Collectors.toList());
            else
                books = bookRepository.findByTitle(title).stream().map(b -> dtoMapper.fromBooktoBookDto(b)).collect(Collectors.toList());
            if (books.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(books, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<List<BookDto>> getBooksByPartOfTitle(String title) {
        try {
            List<BookDto> books = new ArrayList<BookDto>();
            if (title == null)
                books = bookRepository.findAll().stream().map(b -> dtoMapper.fromBooktoBookDto(b)).collect(Collectors.toList());
            else
                books = bookRepository.findByTitleContaining(title).stream().map(b -> dtoMapper.fromBooktoBookDto(b)).collect(Collectors.toList());
            if (books.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(books, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
