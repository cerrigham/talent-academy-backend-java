package it.bitrock.springbootdemo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SpringbootDemoController
{
    @RequestMapping("/")
    public String hello() {
        return "Hello my Friend!";
    }

    @GetMapping("/hello-name")
    public String helloName(@RequestParam String name) {
        return "Hello " + name;
    }
}